// CodeGym Career Landing Page Scripts
$(document).ready(function () {
    // Khởi tạo hiệu ứng sóng Material Design (Waves)
    Waves.init();
    Waves.attach('.btn', ['waves-light']);

    // Xử lý gửi biểu mẫu tư vấn
    $('#careerForm').on('submit', function (e) {
        e.preventDefault();
        var name = $('#formName').val();
        var phone = $('#formPhone').val();
        
        alert('Cảm ơn bạn ' + name + ' (SĐT: ' + phone + ') đã quan tâm đến CodeGym Career! Đội ngũ tư vấn sẽ liên hệ lại với bạn trong vòng 24 giờ làm việc.');
        this.reset();
    });
});